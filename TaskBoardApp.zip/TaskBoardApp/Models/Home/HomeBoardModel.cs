﻿namespace TaskBoardApp.Models.Home
{
    public class HomeBoardModel
    {
        public string BoardName { get; set; } = string.Empty;

        public int TasksCount { get; set; }
    }
}
